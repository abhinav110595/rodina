#define IN_SIZE 64
#define TEMP_IN "temp_64"
#define POWER_IN "power_64"
#define MULTIPLIER 4
#define TEMP_OUT "temp_256"
#define POWER_OUT "power_256"
