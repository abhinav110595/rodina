#define IN_SIZE 1024
#define TEMP_IN "temp_1024"
#define POWER_IN "power_1024"
#define MULTIPLIER 2
#define TEMP_OUT "temp_2048"
#define POWER_OUT "power_2048"