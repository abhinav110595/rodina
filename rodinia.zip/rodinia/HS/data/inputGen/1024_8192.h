#define IN_SIZE 1024
#define TEMP_IN "temp_1024"
#define POWER_IN "power_1024"
#define MULTIPLIER 8
#define TEMP_OUT "temp_8192"
#define POWER_OUT "power_8192"